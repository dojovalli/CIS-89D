<?php
	$num1 = $_POST['num_A'];
	$num2 = $_POST['num_B'];
	
	echo ($num1 + $num2);
?>